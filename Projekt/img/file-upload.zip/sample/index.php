<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>File Upload Example</title>
  </head>
  <body>
    <h1>File Upload Example</h1>

    <h2>Posted Vars</h1>
    <pre><?php

        // dump $_POST & $_FILES
        echo "\$_POST=";
        print_r($_POST);
        echo "\$_FILES=";
        print_r($_FILES);

        // process upload
        if (isset($_POST["upload"]) && isset($_FILES["myfile"])) {

            if ($_FILES["myfile"]["error"] != 0) {
                echo "Error uploading file";
                return;
            }

            // check MIME Type (enable to allow only PDF)
            /*
            $mimetype = mime_content_type($_FILES["myfile"]["tmp_name"]);
            if ($mimetype !== "application/pdf") {
                echo "Error: only PDF allowed, found " . $mimetype;
                return;
            }
            */

            // $filename = "uploads/" . $_FILES["myfile"]["name"]; 
            // $filename = tempnam("uploads", "upload_" . time() . "_");
            $filename =  "uploads/" . uniqid("upload_", true);
            // $filename = tempnam("uploads", "upload_" . time() . "_") . ".txt";

            if (move_uploaded_file($_FILES["myfile"]["tmp_name"], $filename) == false) {
                echo "Error moving uploaded file";
            }
        }

    ?>
    </pre>

    <hr>
    <h2>Upload Form</h1>
    <form enctype="multipart/form-data" method="POST">
        <input type="text" name="info">
        <input type="file" name="myfile">
        <!-- or ... 
        <input type="file" name="myfile" accept="application/pdf">
        -->
        <input type="submit" name="upload" value="Upload File">
    </form>


    <hr>
    <h2>Uploaded files</h2>
    <ul>
    <?php 
        $dir = scandir("uploads");
        foreach ($dir as $v) {
            $filename = "uploads/" . $v;    
            
            if (is_file($filename)) {
                echo "<li>" . $filename . " =&gt; " . mime_content_type($filename) . "</li>";
            }            
        }
    ?>
    </ul>


    <hr>
    <h2>Content of uploads/readme.txt</h2>
    <?php
       
    // print content of a file ...    
    $content = file_get_contents("uploads/readme.txt");
    echo "<pre>" . $content . "</pre>";


    ?>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


  </body>
</html>
