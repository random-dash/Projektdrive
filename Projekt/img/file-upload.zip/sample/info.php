<?php 

phpinfo();

